# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Integrated::Application.config.secret_token = '1b8b580d7673891edc97186c89af9cee4df41a61a373723310b27175ddfefaeb991e9128d9cb7596086698072c7c58d9ef4342c18309fcbf9a9459fd9e4b2b9f'
