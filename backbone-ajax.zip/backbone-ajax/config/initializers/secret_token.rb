# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Integrated::Application.config.secret_token = 'e491faf640b3a9f6759f29da985491d5a0a8e11060bbb7297bc4f15c56c8dca3e65fbb0e3b57e80fb719d22f2153ce3ebbb968782ed54842ad35423a6cf0e321'
