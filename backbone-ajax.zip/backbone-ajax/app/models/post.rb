class Post < ActiveRecord::Base
  attr_accessible :content, :slug, :title
end
