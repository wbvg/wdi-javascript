var app = app || {}

// Create the app router
