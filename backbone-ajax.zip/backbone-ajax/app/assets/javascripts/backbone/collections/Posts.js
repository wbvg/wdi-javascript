var app = app || {}

// Create a collection of blog posts
