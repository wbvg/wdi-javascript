var app = app || {}

// Create the app/home view
