var app = app || {}

// Create an individual post view object
