var app = app || {}

// Create a template for the home page blog post subview
