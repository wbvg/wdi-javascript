var app = app || {}

// Create a model for the posts
